"""MediCore Nexus App Package"""
